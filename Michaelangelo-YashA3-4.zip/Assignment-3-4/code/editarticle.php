<?php include("templates/page_header.php");?>
<?php include("lib/auth.php") ?>
<?php /*The below 6 lines are checking if the user logged in is a student and 
if the post they are trying to access is a 1. If the both conditions are met
they are not allowed to edit an admins post. The else condition checks for student
and author 2(student), or admin trying to edit any post
*/ ?>
<?php /*if(($_SESSION['username']=='student') && ($row['author']=1)){
 Header ("Location: /admin.php");
}else{
 Header ("Location: /");
}*/
?>

<?php
if(($_SERVER['REQUEST_METHOD'] == 'GET')  &&
 (check_csrf())) {
	$aid = $_GET['aid'];	
	$result=get_article($dbconn, $aid);
	$row = pg_fetch_array($result, 0);
} else if (($_SERVER['REQUEST_METHOD'] == 'POST')  &&
 (check_csrf())) {
	$title = $_POST['title'];
	$content = $_POST['content'];
	$aid = $_POST['aid'];
	$result=update_article($dbconn, $title, $content, $aid);
	Header ("Location: /");
}?>

<!doctype html>
<html lang="en">
<head>
	<title>New Post</title>
	<?php include("templates/header.php"); ?>
</head>
<body>
	<?php include("templates/nav.php"); ?>
	<?php include("templates/contentstart.php"); ?>

<h2>New Post</h2>

<form action='#' method='POST'>
	<input type="hidden" value="<?php echo $row['aid'] ?>" name="aid">
	<div class="form-group">
	<label for="inputTitle" class="sr-only">Post Title</label>
	<input type="text" id="inputTitle" required autofocus name='title' value="<?php echo $row['title'] ?>">
	</div>
	<div class="form-group">
	<label for="inputContent" class="sr-only">Post Content</label>
	<textarea name='content' id="inputContent"><?php echo $row['content'] ?></textarea>
	</div>
	<input type="submit" value="Update" name="submit" class="btn btn-primary">
</form>
<br>

	<?php include("templates/contentstop.php"); ?>
	<?php include("templates/footer.php"); ?>
</body>
</html>
