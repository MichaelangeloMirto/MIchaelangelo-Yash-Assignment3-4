<?php include("templates/page_header.php");?>
<?php include("lib/auth.php") ?>
<!doctype html>
<html lang="en">
<head>
	<title>Admin</title>
	<?php include("templates/header.php"); ?>
</head>
<body>
	<?php include("templates/nav.php"); ?>
	<?php include("templates/contentstart.php"); ?> 

<h2>Article Management</h2>

<p><button type="button" class="btn btn-primary" aria-label="Left Align" onclick="window.location='/newarticle.php';">
New Post <span class="fa fa-plus" aria-hidden="true"></span>
</button></p>

<table class="table">
<tr><th>Post Title</th><th>Author</th><th>Date</th><th>Modify</th><th>Delete</th></tr>

<?php
# get articles by user or, if role is admin, all articles
		$result = get_article_list($dbconn);
		while ($row = pg_fetch_array($result)) {
	?>
<tr>
<?php # Adding in the htmlspecialchars line to stop the rendering of all html code being used on the application. HTML code gets rendered as normal text on screen
      /*In the code below we used an if statement to check if the username is admin,
and if the user is logged in as admin they are allowed to do whatever they want with
the posts that are being displayed. The else statement is for the username student,
where they are not allowed to delete posts that are made by admin. Student user
is only allowed to delete posts that are made by the user student.
*/
	?>
<?php if($_SESSION['username']=='admin'){ ?>
  <td><a href='article.php?aid=<?php echo $row['aid'] ?>'><?php echo htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8'); ?></a></td>
  <td><?php echo $row['author'] ?></td>
  <td><?php echo substr($row['date'],0,10) ?></td>
  <td><a href="/editarticle.php?aid=<?php echo $row['aid'] ?>"><i class="fa fa-pencil-square-o fa-2x" aria-hidden="true"></i></a></td>
  <td><a href="/deletearticle.php?aid=<?php echo $row['aid'] ?>"><i class="fa fa-times fa-2x" aria-hidden="true"></i></a></td>
</tr>
<?php }else{    ?>
<td><a href='article.php?aid=<?php echo $row['aid'] ?>'><?php echo htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8'); ?></a></td>
  <td><?php echo $row['author'] ?></td>
  <td><?php echo substr($row['date'],0,10) ?></td>
<?php if($_SESSION['username']=='student'){ ?>
<?php	if($row['author']=='student'){ ?>
  <td><a href="/editarticle.php?aid=<?php echo $row['aid'] ?>"><i class="fa fa-pencil-square-o fa-2x"> 
<?php }else{ ?>
 <td><a href="/editarticle.?aid=<?php echo $row['aid'] ?>"><i class="fa fa-pencil-square-o fa-2x" aria-hidden="true"></i></a></td>
<?php } ?>
<?php } ?>
<?php if($row['author']=='student'){    ?> 
	<td><a href="/deletearticle.php?aid=<?php echo $row['aid'] ?>"><i class="fa fa-times fa-2x" aria-hidden="true"></i></a></td> 
<?php } ?>
<?php } ?>

	<?php } //close while loop  
?>
</table>
	<?php include("templates/contentstop.php"); ?>
	<?php include("templates/footer.php"); ?>
	//<?php
/*Destroys the session so user is forced to log back in and get a token
each time that they access the web application. By default, whens users open
a new web browser they will not be automatically logged in*/ 
//session_destroy(); 
//?>
</body>
</html>
