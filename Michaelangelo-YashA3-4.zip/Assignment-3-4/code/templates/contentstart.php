<main role="main" class="container">
  <div class="row">
    <div class="col blog-main">
