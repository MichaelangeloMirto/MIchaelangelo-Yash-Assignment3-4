	</div><!-- /.blog-main -->
  </div><!-- /.row -->

</main><!-- /.container -->
